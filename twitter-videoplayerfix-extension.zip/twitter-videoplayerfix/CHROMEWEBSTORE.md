# Chrome Web Store Listing — X Video Player Popover Fix

> Last Updated: 2026-09-13

## Store Listing

**Extension Name** [REQUIRED]
X Video Player Popover Fix

**Short Description** [REQUIRED]
Hides the white square popover artifact on X (Twitter) video players for an uninterrupted viewing experience.

**Detailed Description** [REQUIRED]
Fixes the white square popover bug on X (formerly Twitter) video player.

X (Twitter) video playback occasionally renders an unstyled white square box (`div[popover]`) on top of videos and controls. This extension automatically removes the white box artifact by setting its background to transparent and removing the border and padding.

Key Features:
- Instantly hides the white square popover on x.com video players.
- Executes automatically on page load.
- Seamless single-page application (SPA) support: observes dynamic tweet scrolling and video modal mounting.
- Zero-flicker instant CSS override prevents the white square from flashing.
- Clean popup interface showing active status and a one-click manual re-run button.

How to use:
1. Install and enable the extension.
2. Visit https://x.com.
3. Videos and controls will play smoothly without any white square covering the screen.

Privacy & Permissions:
This extension operates 100% locally in your browser. It does not collect, store, or transmit any user data or browsing history.

**Category** [REQUIRED]
Productivity

**Single Purpose** [REQUIRED]
Removes the white square popover artifact on X (Twitter) video players.

**Primary Language** [REQUIRED]
English

## Graphics & Assets

| Asset | Dimensions | Status | Filename |
|-------|-----------|--------|----------|
| Store Icon [REQUIRED] | 128×128 PNG | ✅ Ready | `icons/icon-128.png` |
| Screenshot 1 [REQUIRED] | 1280×800 or 640×400 | ⬜ Not created | |
| Small Promo Tile [RECOMMENDED] | 440×280 | ⬜ Not created | |

## Permissions Justification

| Permission | Type | Justification |
|------------|------|---------------|
| `activeTab` | permissions | Used by the popup to detect if the active tab is x.com and trigger a manual fix if requested by the user. |
| `tabs` | permissions | Used in the popup to inspect the active tab URL to display the current active/standby status. |

## Privacy & Data Use

### Data Collection

**Does the extension collect user data?** No

### Data Use Certification
- [x] Data is NOT sold to third parties
- [x] Data is NOT used for purposes unrelated to the extension's core functionality
- [x] Data is NOT used for creditworthiness or lending purposes

## Distribution

**Visibility**: Public
**Regions**: All regions
**Pricing**: Free

## Version History

| Version | Date | Changes | Status |
|---------|------|---------|--------|
| 1.0.0 | 2026-09-13 | Initial release: automatic popover fix and SPA observer on x.com | Draft |
