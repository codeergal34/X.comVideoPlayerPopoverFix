from PIL import Image, ImageDraw
import os

os.makedirs('icons', exist_ok=True)

sizes = [16, 48, 128]

for size in sizes:
    # 2x supersampling for crisp edges
    scale = 4
    img_size = size * scale
    img = Image.new('RGBA', (img_size, img_size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    margin = int(img_size * 0.08)
    radius = int(img_size * 0.22)

    # Dark background with rounded rectangle
    draw.rounded_rectangle(
        [margin, margin, img_size - margin, img_size - margin],
        radius=radius,
        fill=(15, 20, 25, 255),  # X dark theme
        outline=(29, 155, 240, 255),  # X accent blue
        width=max(1, int(img_size * 0.04))
    )

    # Play button triangle in center
    cx, cy = img_size / 2, img_size / 2
    poly_w = img_size * 0.36
    poly_h = img_size * 0.40

    p1 = (cx - poly_w * 0.38, cy - poly_h * 0.5)
    p2 = (cx - poly_w * 0.38, cy + poly_h * 0.5)
    p3 = (cx + poly_w * 0.62, cy)

    draw.polygon([p1, p2, p3], fill=(29, 155, 240, 255))

    # Downsample to target size with high quality Lanczos filter
    img_resized = img.resize((size, size), Image.Resampling.LANCZOS)
    img_resized.save(f'icons/icon-{size}.png', format='PNG')
    print(f'Generated icons/icon-{size}.png ({size}x{size})')
