/**
 * Twitter / X Video Player White Square Popover Fix
 * Injects styling to hide the white square popover artifact on x.com.
 */

// User-provided fix function
function fixWhiteSquare() {
  const popover = document.querySelector('div[popover]');
  if (popover) {
    popover.style.setProperty('background-color', 'transparent', 'important');
    popover.style.setProperty('border', 'none', 'important');
    popover.style.setProperty('padding', '0', 'important');
    console.log('✅ Fix applied: The white square box is now hidden.');
    return true;
  } else {
    console.log('❌ Could not find the popover element.');
    return false;
  }
}

// 1. Run immediately on initial page load as requested
(function runOnPageLoad() {
  fixWhiteSquare();
})();

// 2. SPA Support: Handle popovers mounted dynamically during video playback or navigation
function applyFixToAll() {
  const popovers = document.querySelectorAll('div[popover]');
  let appliedCount = 0;

  popovers.forEach((popover) => {
    if (popover.dataset.whiteSquareFixed !== 'true') {
      popover.style.setProperty('background-color', 'transparent', 'important');
      popover.style.setProperty('border', 'none', 'important');
      popover.style.setProperty('padding', '0', 'important');
      popover.dataset.whiteSquareFixed = 'true';
      appliedCount++;
    }
  });

  if (appliedCount > 0) {
    console.log(`✅ Fix applied: ${appliedCount} dynamic popover element(s) styled transparent.`);
  }
}

// Observe DOM changes on x.com (debounced with requestAnimationFrame)
let debounceFrame = null;
const observer = new MutationObserver(() => {
  if (debounceFrame) cancelAnimationFrame(debounceFrame);
  debounceFrame = requestAnimationFrame(() => {
    applyFixToAll();
  });
});

const startObserver = () => {
  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
    applyFixToAll();
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.body, { childList: true, subtree: true });
      applyFixToAll();
    });
  }
};

startObserver();

// 3. Listen for manual triggers from the extension popup
if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'RUN_FIX') {
      const found = fixWhiteSquare();
      applyFixToAll();
      sendResponse({ status: 'completed', popoverFound: found });
    }
    return false;
  });
}
