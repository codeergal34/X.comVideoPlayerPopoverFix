# X (Twitter) Video Player Popover Fix

A Manifest V3 Chrome Extension that hides the unwanted white square box (`div[popover]`) on [x.com](https://x.com/) video players.

## Features

- **Automatic Injection on Page Load**: Injects your fix script as soon as `x.com` loads.
- **Dynamic SPA Support**: Uses a lightweight `MutationObserver` (debounced with `requestAnimationFrame`) to handle newly mounted video players and tweet modals while browsing without page reloads.
- **Zero-Flicker CSS**: Bundles a companion CSS stylesheet that ensures any `div[popover]` renders transparent instantly before it can flash on screen.
- **Popup Control**: Clean dark-mode popup showing active status and a "Re-apply Fix Now" button for testing.

---

## Injected Logic

The extension runs your code on page load:

```javascript
(function fixWhiteSquare() {
  const popover = document.querySelector('div[popover]');
  if (popover) {
    popover.style.setProperty('background-color', 'transparent', 'important');
    popover.style.setProperty('border', 'none', 'important');
    popover.style.setProperty('padding', '0', 'important');
    console.log('✅ Fix applied: The white square box is now hidden.');
  } else {
    console.log('❌ Could not find the popover element.');
  }
})();
```

---

## How to Install in Chrome

1. Open Google Chrome.
2. Navigate to `chrome://extensions/` in the address bar.
3. Enable **Developer mode** using the toggle in the top-right corner.
4. Click the **Load unpacked** button in the top-left corner.
5. Select this folder:
   ```
   /Users/surya/Documents/GitHub/extensions/twitter-videoplayerfix
   ```
6. The extension **X Video Player Popover Fix** will now appear in your extensions list.

---

## How to Verify

1. Open [https://x.com](https://x.com) in Chrome.
2. Open Chrome Developer Tools (**F12** or **Cmd + Option + I**) and switch to the **Console** tab.
3. Look for the message:
   ```
   ✅ Fix applied: The white square box is now hidden.
   ```
   *(Or `❌ Could not find the popover element.` if no video popover is currently present, followed by `✅ Fix applied: ...` once a video/popover mounts).*
4. Click the extension icon in Chrome's toolbar to see the status popup and test manually.
