document.addEventListener('DOMContentLoaded', async () => {
  const runFixBtn = document.getElementById('runFixBtn');
  const statusText = document.getElementById('statusText');
  const feedback = document.getElementById('feedback');

  // Check if current tab is x.com
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const isX = tab?.url && (tab.url.startsWith('https://x.com') || tab.url.startsWith('https://twitter.com'));

    if (!isX) {
      statusText.textContent = 'Standby (Open x.com)';
      statusText.style.color = '#9ca3af';
      const dot = document.querySelector('.status-dot');
      if (dot) {
        dot.style.background = '#9ca3af';
        dot.style.boxShadow = 'none';
        dot.style.animation = 'none';
      }
    }
  } catch {
    // If tabs query fails, keep default active state
  }

  // Handle manual fix button click
  runFixBtn.addEventListener('click', async () => {
    feedback.textContent = 'Applying fix...';
    feedback.style.color = '#9ca3af';

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) {
        feedback.textContent = 'No active tab found.';
        feedback.style.color = '#f87171';
        return;
      }

      if (!tab.url || (!tab.url.startsWith('https://x.com') && !tab.url.startsWith('https://twitter.com'))) {
        feedback.textContent = 'Please switch to an x.com tab.';
        feedback.style.color = '#f87171';
        return;
      }

      const response = await chrome.tabs.sendMessage(tab.id, { action: 'RUN_FIX' });
      if (response?.popoverFound) {
        feedback.textContent = '✅ Fix applied: Popover hidden!';
        feedback.style.color = '#00ba7c';
      } else {
        feedback.textContent = '✅ Fix executed (No popovers currently on screen).';
        feedback.style.color = '#1d9bf0';
      }
    } catch {
      // Content script may not be injected yet or page needs refresh
      feedback.textContent = 'Refresh the x.com page to inject the fix.';
      feedback.style.color = '#f87171';
    }
  });
});
